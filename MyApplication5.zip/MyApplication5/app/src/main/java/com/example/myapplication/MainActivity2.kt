package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)
        val extras=intent.extras
        val name=extras?.getString("item")
        val txt:TextView=findViewById(R.id.textView)
        txt.text=name.toString()

        val op:Button=findViewById(R.id.ordplace)
        val menu:Button=findViewById(R.id.mainmenu)

        val qtyEdit:EditText=findViewById(R.id.qty)
        val priceEdit:EditText=findViewById(R.id.price)

        op.setOnClickListener{
            val qty = qtyEdit.text.toString()
            val price = priceEdit.text.toString()
            val total = qty.toInt() * price.toInt()
            intent=Intent(this,MainActivity3::class.java)
            intent.putExtra("Quantity",qty.toInt())
            intent.putExtra("Total",total)
            startActivity(intent)
        }

        menu.setOnClickListener{
            intent=Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.menu)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
