package com.example.myapplication


import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val list:ListView=findViewById(R.id.list)
        val arr= arrayOf(
            "Bat",
            "Ball",
            "Stump",
            "Pad",
            "Helmet",
            "Gloves",
            "Shoes",
            "Cap",
            "Inner Gloves",
            "Bail",
            "Practice Nets",
            "Bowling Machine"
        )
        list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,arr)

        list.setOnItemClickListener { adapterView, view, i, l ->
            val selectedItem = arr[i]
            intent= Intent(this,MainActivity2::class.java)
            intent.putExtra("item",selectedItem)
            startActivity(intent)
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.menu)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
